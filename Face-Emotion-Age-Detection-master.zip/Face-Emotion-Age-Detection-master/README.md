# Face-Emotion-Age-Detection
A web app to detect faces and display their emotions and ages in real-time with the use of [ace-api.js](https://github.com/justadudewhohacks/face-api.js).

face-api.js is a JavaScript API for face detection and face recognition in the browser and nodejs with tensorflow.js
